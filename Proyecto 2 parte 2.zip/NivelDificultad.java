import java.util.ArrayList;
import java.util.List;

/**
 * La clase NivelDificultad representa un nivel de dificultad en un juego o aplicación.
 */
class NivelDificultad {
    private String nombre;
    private List<Tema> temas;

    /**
     * Constructor de la clase NivelDificultad.
     *
     * @param nombre El nombre del nivel de dificultad.
     */
    public NivelDificultad(String nombre) {
        this.nombre = nombre;
        this.temas = new ArrayList<>();
    }

    /**
     * Obtiene el nombre del nivel de dificultad.
     *
     * @return El nombre del nivel de dificultad.
     */
    public String getNombre() {
        return this.nombre;
    }

    /**
     * Establece el nombre del nivel de dificultad.
     *
     * @param nombre El nuevo nombre del nivel de dificultad.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene la lista de temas asociados a este nivel de dificultad.
     *
     * @return La lista de temas del nivel de dificultad.
     */
    public List<Tema> getTemas() {
        return this.temas;
    }

    /**
     * Establece la lista de temas del nivel de dificultad.
     *
     * @param temas La nueva lista de temas del nivel de dificultad.
     */
    public void setTemas(List<Tema> temas) {
        this.temas = temas;
    }

    /**
     * Agrega un tema a la lista de temas del nivel de dificultad.
     *
     * @param tema El tema a agregar.
     */
    public void agregarTema(Tema tema) {
        this.temas.add(tema);
    }
}
