/**
 * La clase Tema representa un tema que puede estar asociado con una prueba.
 */
class Tema {
    private String nombre;
    private String informacion;
    private Prueba prueba;

    /**
     * Constructor de la clase Tema.
     *
     * @param nombre     El nombre del tema.
     * @param informacion La información asociada al tema.
     */
    public Tema(String nombre, String informacion) {
        this.nombre = nombre;
        this.informacion = informacion;
    }

    /**
     * Obtiene el nombre del tema.
     *
     * @return El nombre del tema.
     */
    public String getNombre() {
        return this.nombre;
    }

    /**
     * Establece el nombre del tema.
     *
     * @param nombre El nuevo nombre del tema.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene la información asociada al tema.
     *
     * @return La información del tema.
     */
    public String getInformacion() {
        return this.informacion;
    }

    /**
     * Establece la información asociada al tema.
     *
     * @param informacion La nueva información del tema.
     */
    public void setInformacion(String informacion) {
        this.informacion = informacion;
    }

    /**
     * Obtiene la prueba asociada al tema.
     *
     * @return La prueba asociada al tema.
     */
    public Prueba getPrueba() {
        return this.prueba;
    }

    /**
     * Establece la prueba asociada al tema.
     *
     * @param prueba La nueva prueba asociada al tema.
     */
    public void setPrueba(Prueba prueba) {
        this.prueba = prueba;
    }

    /**
     * Muestra la información del tema.
     */
    public void mostrarInformacion() {
        System.out.println(this.informacion);
    }
}
