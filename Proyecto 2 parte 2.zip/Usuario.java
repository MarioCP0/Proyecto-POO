import java.util.Scanner;

/**
 * La clase Usuario representa a un usuario que puede configurar su nombre, nivel de dificultad
 * y tema actual.
 */
class Usuario {
    private String nombre;
    private NivelDificultad nivelDificultad;
    private Tema temaActual;

    /**
     * Constructor de la clase Usuario.
     *
     * @param nombre El nombre del usuario.
     */
    public Usuario(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el nombre del usuario.
     *
     * @return El nombre del usuario.
     */
    public String getNombre() {
        return this.nombre;
    }

    /**
     * Establece el nombre del usuario.
     *
     * @param nombre El nuevo nombre del usuario.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el nivel de dificultad actual del usuario.
     *
     * @return El nivel de dificultad actual.
     */
    public NivelDificultad getNivelDificultad() {
        return this.nivelDificultad;
    }

    /**
     * Establece el nivel de dificultad del usuario.
     *
     * @param nivelDificultad El nuevo nivel de dificultad.
     */
    public void setNivelDificultad(NivelDificultad nivelDificultad) {
        this.nivelDificultad = nivelDificultad;
    }

    /**
     * Obtiene el tema actual del usuario.
     *
     * @return El tema actual.
     */
    public Tema getTemaActual() {
        return this.temaActual;
    }

    /**
     * Establece el tema actual del usuario.
     *
     * @param temaActual El nuevo tema actual.
     */
    public void setTemaActual(Tema temaActual) {
        this.temaActual = temaActual;
    }

    /**
     * Permite al usuario elegir un nivel de dificultad.
     *
     * @param nivel El nivel de dificultad elegido por el usuario.
     */
    public void elegirNivelDificultad(NivelDificultad nivel) {
        this.nivelDificultad = nivel;
        System.out.println("Has elegido el nivel de dificultad: " + nivel.getNombre());
    }

    /**
     * Permite al usuario elegir un tema.
     *
     * @param tema El tema elegido por el usuario.
     */
    public void elegirTema(Tema tema) {
        this.temaActual = tema;
        System.out.println("Has elegido el tema: " + tema.getNombre());
        tema.mostrarInformacion();
    }

    /**
     * Permite al usuario elegir un nivel de dificultad a través de la entrada de usuario.
     */
    public void elegirNivelDificultad() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Por favor, elige un nivel de dificultad: Básico, Intermedio, Avanzado (sin tildes y en minúsculas)");
        String nivel = scanner.nextLine();

        switch (nivel.toLowerCase()) {
            case "basico":
                this.nivelDificultad = new NivelDificultad("Básico");
                break;
            case "intermedio":
                this.nivelDificultad = new NivelDificultad("Intermedio");
                break;
            case "avanzado":
                this.nivelDificultad = new NivelDificultad("Avanzado");
                break;
            default:
                System.out.println("No se reconoció el nivel de dificultad. Por favor, intenta de nuevo.");
                elegirNivelDificultad();
                break;
        }

        System.out.println("Has elegido el nivel de dificultad: " + nivel);
    }
}
