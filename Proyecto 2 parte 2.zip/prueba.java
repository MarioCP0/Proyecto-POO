import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * La clase Prueba permite realizar una prueba de preguntas y respuestas.
 */
class Prueba {
    private List<String> preguntas;
    private List<String> respuestasCorrectas;

    /**
     * Constructor de la clase Prueba.
     *
     * @param preguntas           La lista de preguntas de la prueba.
     * @param respuestasCorrectas La lista de respuestas correctas correspondientes a las preguntas.
     */
    public Prueba(List<String> preguntas, List<String> respuestasCorrectas) {
        this.preguntas = preguntas;
        this.respuestasCorrectas = respuestasCorrectas;
    }

    /**
     * Obtiene la lista de preguntas de la prueba.
     *
     * @return La lista de preguntas.
     */
    public List<String> getPreguntas() {
        return this.preguntas;
    }

    /**
     * Establece la lista de preguntas de la prueba.
     *
     * @param preguntas La nueva lista de preguntas.
     */
    public void setPreguntas(List<String> preguntas) {
        this.preguntas = preguntas;
    }

    /**
     * Obtiene la lista de respuestas correctas correspondientes a las preguntas.
     *
     * @return La lista de respuestas correctas.
     */
    public List<String> getRespuestasCorrectas() {
        return this.respuestasCorrectas;
    }

    /**
     * Establece la lista de respuestas correctas correspondientes a las preguntas.
     *
     * @param respuestasCorrectas La nueva lista de respuestas correctas.
     */
    public void setRespuestasCorrectas(List<String> respuestasCorrectas) {
        this.respuestasCorrectas = respuestasCorrectas;
    }

    /**
     * Inicia la prueba y solicita respuestas a las preguntas. Calcula el puntaje y muestra el resultado.
     */
    public void iniciarPrueba() {
        Scanner scanner = new Scanner(System.in);
        int score = 0;

        for (int i = 0; i < preguntas.size(); i++) {
            System.out.println(preguntas.get(i));
            String respuestaUsuario = scanner.nextLine();

            if (respuestaUsuario.equalsIgnoreCase(respuestasCorrectas.get(i))) {
                score++;
            }
        }

        System.out.println("Tu puntuación es: " + score + "/" + preguntas.size());
    }
}
